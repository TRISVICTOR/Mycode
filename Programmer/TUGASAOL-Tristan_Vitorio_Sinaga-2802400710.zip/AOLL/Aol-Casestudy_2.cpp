#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>

int jumlahData=0;//global variabel

struct Data{
	char location[10000];
	char city[10000];
	int price;
	int room;
	int bathroom;
	int carpark;
	char type[10000];
	char furnish[10000];
}dSort[10000];
//function buat baca filenya
void readFile(FILE* fp){
    
    while(!feof(fp)){
		fscanf(fp, "%[^,],%[^,],%d,%d,%d,%d,%[^,],%[^\n]\n", dSort[jumlahData].location, dSort[jumlahData].city, &dSort[jumlahData].price, &dSort[jumlahData].room, &dSort[jumlahData].bathroom, &dSort[jumlahData].carpark, dSort[jumlahData].type, dSort[jumlahData].furnish);
		jumlahData++;
    }
    
    fclose(fp);
}
//function buat menampung judulnya agar tidak terdeterksi
void removerHeader(FILE *fp){
	char header1[1001];
	char header2[1001];
	char header3[1001];
	char header4[1001];
	char header5[1001];
	char header6[1001];
	char header7[1001];
	char header8[1001];
	fscanf(fp, "%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n", header1, header2, header3, header4, header5, header6, header7, header8);
}
//ini buat perbadingan
int locationA(Data a,Data b){
	return strcmp(a.location,b.location);
}
int locationD(Data a,Data b){
	return strcmp(b.location,a.location);
}
int cityA(Data a,Data b){
	return strcmp(a.city,b.city);
}
int cityD(Data a,Data b){
	return strcmp(b.city,a.city);
}
int priceA(Data a,Data b){
	return a.price-b.price;
}
int priceD(Data a,Data b){
	return b.price-a.price;
}
int roomA(Data a,Data b){
	return a.room-b.room;
}
int roomD(Data a,Data b){
	return b.room-a.room;
}
int bathroomA(Data a,Data b){
	return a.bathroom-b.bathroom;
}
int bathroomD(Data a,Data b){
	return b.bathroom-a.bathroom;
}
int carparkA(Data a,Data b){
	return a.bathroom-b.bathroom;
}
int carparkD(Data a,Data b){
	return b.bathroom-a.bathroom;
}
int typeA(Data a,Data b){
	return strcmp(a.type,b.type);
}
int typeD(Data a,Data b){
	return strcmp(b.city,a.city);
}
int furnishA(Data a,Data b){
	return strcmp(a.type,b.type);
}
int furnishD(Data a,Data b){
	return strcmp(b.city,a.city);
}
//untuk quicksort
void tuker(Data *a,Data *b){
	Data c=*a;
	*a=*b;
	*b=c;
}
//untuk function sort
int quick(Data d[],int left,int right,int (*compare)(Data,Data)){
	Data pivot=d[right];
	int i=left-1;
	for(int j=left;j<=right-1;j++){
		if(compare(d[j],pivot)<=0){
			i++;
			tuker(&d[i],&d[j]);
		}
	}
	tuker(&d[i+1],&d[right]);
	return i+1;
}
//untuk function quicksort
void quicksort(Data d[],int left,int right,int(*cmp)(Data,Data)){
	if(left<right){
		int pi=quick(d,left,right,cmp);
		
		quicksort(d,left,pi-1,cmp);
		quicksort(d,pi+1,right,cmp);
	}
}
//buat function display pada pilihan 1
void displaydata(){
	long long int baris;
	do{
		printf("Number Of Rows: ");
		scanf("%lld",&baris);getchar();
	}while(baris<0 && baris>jumlahData);
	
	puts("");
	
	printf("Location             City             Price       Rooms  Bathroom    Carpark     Type        Furnish\n\n");
	
	for(int i=0;i<baris;i++){
		printf("%-20s %-16s %-11d %-6d %-11d %-11d %-11s %s\n",dSort[i].location,dSort[i].city,dSort[i].price,dSort[i].room,dSort[i].bathroom,dSort[i].carpark,dSort[i].type,dSort[i].furnish);
	}
	
	printf("\n");
}
//buat function searchdata pada pilihan ke 2
void searchdata() {
    char kolom[1001];
    printf("Choose column: ");
    scanf("%[^\n]", &kolom); getchar();

    char cariapa[1001];
    printf("What data do you want to find? ");
    scanf("%[^\n]", cariapa); getchar();

    int found = 0;

    for (int i = 1; i < jumlahData; i++) {
        bool ketemu = false;

        if (strcmpi(kolom, "location") == 0 && strcmp(dSort[i].location, cariapa) == 0) ketemu = true;
        else if (strcmpi(kolom, "city") == 0 && strcmp(dSort[i].city, cariapa) == 0) ketemu = true;
        else if (strcmpi(kolom, "bathroom") == 0 && dSort[i].bathroom == atoi(cariapa)) ketemu = true;
        else if (strcmpi(kolom, "carpark") == 0 && dSort[i].carpark == atoi(cariapa)) ketemu = true;
        else if (strcmpi(kolom, "furnish") == 0 && strcmp(dSort[i].furnish, cariapa) == 0) ketemu = true;
        else if (strcmpi(kolom, "prize") == 0 && dSort[i].price == atoi(cariapa)) ketemu = true;
        else if (strcmpi(kolom, "room") == 0 && dSort[i].room == atoi(cariapa)) ketemu = true;
        else if (strcmpi(kolom, "type") == 0 && strcmp(dSort[i].type, cariapa) == 0) ketemu = true;

        if (ketemu == true) {
            if (found == 0) {
                printf("Data found. Detail of data:\n");
                printf("Location             City             Price       Rooms  Bathroom    Carpark     Type        Furnish\n");
            }
            printf("%-20s %-16s %-11d %-6d %-11d %-11d %-11s %s\n", 
                   dSort[i].location, dSort[i].city, dSort[i].price, dSort[i].room, 
                   dSort[i].bathroom, dSort[i].carpark, dSort[i].type, dSort[i].furnish);
            found++;
        }
    }

    if (found == 0) {
        printf("Data not found!\n");
    }

    printf("\n");
}
//buat function sortdata pada pilihan ke 3
void sortdata(){
	char kolom[1001];
	do{
		printf("Choose column: ");
		scanf("%[^\n]",&kolom);getchar();
	}while(!(strcmpi(kolom, "location") == 0 || strcmpi(kolom, "city") == 0 || strcmpi(kolom, "price") == 0 || strcmpi(kolom, "room") == 0 || strcmpi(kolom, "bathroom") == 0 || strcmpi(kolom, "carpark") == 0 || strcmpi(kolom, "type") == 0 || strcmpi(kolom, "furnish") == 0));
	
	if(strcmpi(kolom,"location")==0){
		char apa[1001];
		do{
			printf("Sort ascending or descending? ");
			scanf("%[^\n]",&apa);getchar();
		}while(!(strcmpi(apa,"asc")==0 || strcmpi(apa,"desc")==0));
		
		if(strcmpi(apa,"asc")==0){
			quicksort(dSort,0,jumlahData-1,locationA);
		}
		else{
			quicksort(dSort,0,jumlahData-1,locationD);
		}
	}
	else if(strcmpi(kolom,"city")==0){
		char apa[1001];
		do{
			printf("Sort ascending or descending? ");
			scanf("%[^\n]",&apa);getchar();
		}while(!(strcmpi(apa,"asc")==0 || strcmpi(apa,"desc")==0));
		
		if(strcmpi(apa,"asc")==0){
			quicksort(dSort,0,jumlahData-1,cityA);
		}
		else{
			quicksort(dSort,0,jumlahData-1,cityD);
		}
	}
	else if(strcmpi(kolom,"price")==0){
		char apa[1001];
		do{
			printf("Sort ascending or descending? ");
			scanf("%[^\n]",&apa);getchar();
		}while(!(strcmpi(apa,"asc")==0 || strcmpi(apa,"desc")==0));
		
		if(strcmpi(apa,"asc")==0){
			quicksort(dSort,0,jumlahData-1,priceA);
		}
		else{
			quicksort(dSort,0,jumlahData-1,priceD);
		}
	}
	else if(strcmpi(kolom,"room")==0){
		char apa[1001];
		do{
			printf("Sort ascending or descending? ");
			scanf("%[^\n]",&apa);getchar();
		}while(!(strcmpi(apa,"asc")==0 || strcmpi(apa,"desc")==0));
		
		if(strcmpi(apa,"asc")==0){
			quicksort(dSort,0,jumlahData-1,roomA);
		}
		else{
			quicksort(dSort,0,jumlahData-1,roomD);
		}
	}
	else if(strcmpi(kolom,"bathroom")==0){
		char apa[1001];
		do{
			printf("Sort ascending or descending? ");
			scanf("%[^\n]",&apa);getchar();
		}while(!(strcmpi(apa,"asc")==0 || strcmpi(apa,"desc")==0));
		
		if(strcmpi(apa,"asc")==0){
			quicksort(dSort,0,jumlahData-1,bathroomA);
		}
		else{
			quicksort(dSort,0,jumlahData-1,bathroomD);
		}
	}
	else if(strcmpi(kolom,"carpark")==0){
		char apa[1001];
		do{
			printf("Sort ascending or descending? ");
			scanf("%[^\n]",&apa);getchar();
		}while(!(strcmpi(apa,"asc")==0 || strcmpi(apa,"desc")==0));
		
		if(strcmpi(apa,"asc")==0){
			quicksort(dSort,0,jumlahData-1,carparkA);
		}
		else{
			quicksort(dSort,0,jumlahData-1,carparkD);
		}
	}
	else if(strcmpi(kolom,"type")==0){
		char apa[1001];
		do{
			printf("Sort ascending or descending? ");
			scanf("%[^\n]",&apa);getchar();
		}while(!(strcmpi(apa,"asc")==0 || strcmpi(apa,"desc")==0));
		
		if(strcmpi(apa,"asc")==0){
			quicksort(dSort,0,jumlahData-1,typeA);
		}
		else{
			quicksort(dSort,0,jumlahData-1,typeD);
		}
	}
	else if(strcmpi(kolom,"furnish")==0){
		char apa[1001];
		do{
			printf("Sort ascending or descending? ");
			scanf("%[^\n]",&apa);getchar();
		}while(!(strcmpi(apa,"asc")==0 || strcmpi(apa,"desc")==0));
		
		if(strcmpi(apa,"asc")==0){
			quicksort(dSort,0,jumlahData-1,furnishA);
		}
		else{
			quicksort(dSort,0,jumlahData-1,furnishD);
		}
	}
	
	printf("Data found. Detail of data:\n");
	printf("Location             City             Price       Rooms  Bathroom    Carpark     Type        Furnish\n");

	for(int i = 0; i < 10; i++){
		printf("%-20s %-16s %-11d %-6d %-11d %-11d %-11s %s\n", dSort[i].location, dSort[i].city, dSort[i].price, dSort[i].room, dSort[i].bathroom, dSort[i].carpark, dSort[i].type, dSort[i].furnish);
	}
	printf("\n");
}
//buat function exportdata pada pilihan ke 4
void exportdata(){
	char filename[1001];
	do{
		printf("File Name: ");
		filename[0]='\0';
		scanf("%[^\n]",filename);getchar();
	}while(strlen(filename)==0);
	
	strcat(filename,".csv");
	printf("Data successfully written to file %s\n",filename);
	
	FILE *fp=fopen(filename,"w");
	for(int i=0;i<jumlahData;i++){
		fprintf(fp, "%s,%s,%d,%d,%d,%d,%s,%s\n", dSort[i].location, dSort[i].city, dSort[i].price, dSort[i].room, dSort[i].bathroom, dSort[i].carpark, dSort[i].type, dSort[i].furnish);
	}
	
	fclose(fp);
}

int main(){
	
	FILE *fp=fopen("file.csv","r");
	removerHeader(fp);
	readFile(fp);
	
	int pilih;
	
	do{
		system("cls");
		printf("What do you want to do\n");
		printf("1. Display Data\n");
		printf("2. Search Data\n");
		printf("3. Sort Data\n");
		printf("4. Export Data\n");
		printf("5. Exit\n");
		printf("Your Choice : ");
		scanf("%d",&pilih);getchar();
		
		switch(pilih){
			case 1:
				displaydata();
				break;
			case 2:
				searchdata();
				break;
			case 3:
				sortdata();
				break;
			case 4:
				exportdata();
				break;
			case 5:
				printf("Thanks You\n");
				exit(0);
				break;
			default:
				printf("Ga ada pilihannya.\n");
				printf("Pilih lah yang sesuai.\n\n");
				break;
		}
		printf("Press Enter To Continue...");getchar();
	}while(1);
	
	return 0;
}
