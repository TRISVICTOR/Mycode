#include<stdio.h>
#include<string.h>

void balik(char* arr){
	int panjang=strlen(arr);
	
	for(int i=0;i<panjang/2;i++){
		char huruf=arr[i];
		arr[i]=arr[panjang-1-i];
		arr[panjang-1-i]=huruf;
	}
}

int main(){
	
	char arr[101];
	scanf("%s",&arr);
	
	balik(arr);
	
	for(int i=0;i<strlen(arr);i++){
		if(arr[i]>='a' && arr[i]<='z'){
			arr[i]-=32;
		}
		else if(arr[i]>='A' && arr[i]<='Z'){
			arr[i]+=32;
		}
		printf("%c",arr[i]);
	}
	
	printf("\n");
	
	return 0;
}
