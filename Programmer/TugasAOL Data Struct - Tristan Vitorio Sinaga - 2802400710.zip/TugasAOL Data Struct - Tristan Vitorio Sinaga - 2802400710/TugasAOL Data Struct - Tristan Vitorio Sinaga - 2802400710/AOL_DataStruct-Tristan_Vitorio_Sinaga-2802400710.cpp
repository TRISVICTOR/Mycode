#include<stdio.h>//Untuk scanf, printf, getchar
#include<stdlib.h>//Untuk alokasi memori, koversi, dan fungsi exit
#include<stdbool.h>//Untuk menggunakan boolean
#include<string.h>//Untuk memanipulasi string

#define jumlahChar 26 //Untuk ganti jumlahChar menjadi 26 sesuai abjad a-z

//Structnya
struct Node{
	Node *children[jumlahChar]; //Untuk pointer slangnya, dan membantu kita langsung tau apakah itu anak dri node ini atau tidak
	bool terminal; //Akan menandai apakah akhir dari sebuat kata
	char description[255]; //Untuk menyimpan desc dari slangnya
} *root;

//Untuk membuat Node Baru
Node *newnode(){
	Node *curr = (Node*)malloc(sizeof(Node));
	curr->terminal = false;
	curr->description[0] = '\0';
	for(int i = 0;i<jumlahChar;i++){
		curr->children[i] = NULL;
	}
	return curr;
}

//Insert 
void insert(Node **curr, char *slang, char *desc){
	if(*curr == NULL){ //Buat Node baru jika currnya NULL
		*curr = newnode();
	}
	
	Node *temp = *curr;//Pointer bantuan
	
	for(int i = 0;i<strlen(slang);i++){
		int index = slang[i] - 'a';//Untuk mengubah dari huruf menjadi angka
		
		if(temp->children[index] == NULL){
			temp->children[index] = newnode();//Buat Node baru jika NULL
		}
		temp = temp->children[index];//Jika tidak NULL maju ke index berikutnya
	}
	
	temp->terminal = true;//Untuk menandai akhir kata
	strcpy(temp->description, desc);//Untuk masukin desc
}

//Search
Node *search(Node *curr, char *slang){
	if(curr == NULL){
		return NULL;//Jika ga ketemu bakal NULL
	}
	
	Node *temp = curr;//Pointer bantuan
	
	for(int i = 0;i<strlen(slang);i++){
		int index = slang[i] - 'a';//Untuk mengubah dari huruf menjadi angka
		
		if(temp->children[index] == NULL){//Jika tidak ketemu keluarin NULL
			return NULL;
		}
		temp = temp->children[index];//Ke nextnya
	}
	return temp->terminal ? temp : NULL;//Untuk kembalikan nilainya jika ada, jika ga ada bakal kembalikan NULL
}

//Untuk mengecek slang
bool validSlang(char *slang){
	if(strlen(slang) <= 1 || strchr(slang, ' ')){//Untuk mengecek apakah Slangnya udah lebih dari 1 karakter dan tidak memiliki spasi
		return false;//Bakal return false jika kurang dari 1 karakter dan memiliki spasi
	}
	return true;//Kalau udah bener bakal return True
}

//Untuk mengecek desc
bool validDesc(char *desc){
	int word = 0;//Untuk menghitung berapa jumlah desc
	bool theWord = false;//Untuk mengecek akhir dari kata
	
	for(int i = 0;i<strlen(desc);i++){
		if(desc[i] != ' '){//Untuk mengecek apakah ada spasi
			if(theWord == false){//Untuk ngecek apakah masih ada kata
				word++;//Word ditambah
				theWord = true;//Udah kata terkahir
			}
		}
		else{//Jika ga ada spasi
			theWord = false;
		}
	}
	return word >= 2;
}

int urutan2 = 1;//Variabel global untuk urutan saat print

//Print slang dengan prefix
void printSlangPrefix(Node *curr, char *word, int height){
	if(curr->terminal != NULL){
		word[height] = '\0';//Akhir stringnya
		printf("%d. %s\n",urutan2,word);//print urutan dan katanya
		urutan2++;//Menambahkan urutannya
	}
	
	for(int i=0;i<jumlahChar;i++){
		if(curr->children[i] != NULL){
			word[height] = 'a' + i;//Menyusun kata dari wordnya yang akan dilaluinya
			printSlangPrefix(curr->children[i],word,height+1);//Lakukan rekursi dengan huruf selanjutnya
		}
	}
}

//Untuk mencari prefix
void findPrefix(Node *curr, char *prefix){
	urutan2 = 1;//Untuk memastikan urutan akan selalu dimulai dari 1
	for(int i=0;i<strlen(prefix);i++){
		int index = prefix[i] - 'a';//Untuk mengubah dari huruf menjadi angka
		
		if(curr->children[index] == NULL){//Jika tidak ketemu
			printf("There is no prefix \"%s\" in the dictionary.\n",prefix);
			return;
		}
		curr = curr->children[index];//Untuk ke selanjutnya
	}
	
	//Print semua kata seletahnya
	printf("\nWords starts with \"%s\":\n", prefix);
	int tinggi = strlen(prefix);//Untuk menyimpan panjang string dari prefix
	char word[255];
	strcpy(word,prefix);//masukan prefix ke word
	printSlangPrefix(curr, word, tinggi);//Gunakan function printSlangPrefix untuk print semuanya
}

int urutan = 1;//Variabel global untuk urutan saat print

//Untuk print all
void PrintAll(Node *curr, char *word, int level){
	if(curr->terminal == true){//Jika udah akhir kata
		word[level] = '\0';//Untuk mengakhiri dengan NULL
		printf("%d. %s\n",urutan,word);
		urutan++;//Urutan ditambah
	}
	
	for(int i = 0;i<jumlahChar;i++){
		if(curr->children[i] != NULL){//Jika tidak NULL
			word[level] = i + 'a';////Menyusun kata dari wordnya yang akan dilaluinya
			PrintAll(curr->children[i],word,level+1);//Rekursi
		}
	}
}

//Untuk print jika ada dan jika ga ada
void PrintHeader(Node *curr){
	if(curr == NULL){//Jika kosong
		printf("There is no slang word yet in the dictionary.\n");
		return;
	}
	else{//Jika ada
		printf("List of all slang words in the dictionary:\n");
		char word[125];
		urutan = 1;//Agar urutan selalu dimulai dengan 1
		PrintAll(curr, word, 0);
	}
}

//Untuk exit
void Exit(){
	printf("Thank you... Have a nice day :)\n");
	exit(0);
}

int main(){
	
	root = NULL;//Inisialisasi root
	
	int choice;//Untuk pilihan mau ngapain
	char word[125];//Untuk menampung slang sementara
	char slang[50];//Untuk menampung slang
	char desc[255];//Untuk menampung desc
	char prefix[100];//Untuk menampung prefix
	
	do{
		//Tampilan menu utama
		system("cls");//Untuk mengclear layar
		printf("1. Release a new slang word\n");
		printf("2. Search a slang word\n");
		printf("3. View all slang words starting with a certain prefix word\n");
		printf("4. View all slang words\n");
		printf("5. exit\n");
		printf("Input what you want to do : ");
		scanf("%d",&choice);getchar();//Untuk input mau ngapain
		
		switch(choice){
			case 1:{
				do{
					//Input slang baru
					printf("Input a new slang word [Must be more than 1 characters and contains no space]: ");
					scanf("%[^\n]",slang);
					getchar();
				}while(validSlang(slang) == false);
				
				for(int i = 0;i<strlen(slang);i++){//Mengubah semuanya jadi huruf kecil
					if(slang[i] >= 'A' && slang[i] <= 'Z'){
						slang[i] = slang[i] + 32;
					}
				}
				
				do{
					//Input desc
					printf("Input a new slang word description [Must be more than 2 words]: ");
					scanf("%[^\n]",desc);
					getchar();
				}while(validDesc(desc) == false);
				
				Node *curr = search(root,slang);//Cek apakah sudah ada atau belum
				
				if(curr){//Jika sudah ada
					strcpy(curr->description, desc);
					printf("\nSuccessfully updated a slang word.\n");
				}
				else{//Jika belum ada
					insert(&root, slang, desc);
					printf("\nSuccessfully released new slang word.\n");
				}
				break;
			}
			case 2:{
				do{
					//Input slang yang mau dicari
					printf("Input a slang word to be searched [Must be more than 1 characters and contains no space]: ");
					scanf("%[^\n]",slang);
					getchar();
				}while(validSlang(slang) == false);
				
				for(int i = 0;i<strlen(slang);i++){//Mengubah semuanya jadi huruf kecil
					if(slang[i] >= 'A' && slang[i] <= 'Z'){
						slang[i] = slang[i] + 32;
					}
				}
				
				Node *curr = search(root,slang);//Cari slang
				if(curr != NULL){//Jika ada
					printf("\nSlang word  : %s",slang);
					printf("\nDescription : %s\n",curr->description);
				}
				else{//Jika ga ada
					printf("\nThere is no word \"%s\" in the dictionary.",slang);
				}
				break;
			}
			case 3:{
				//Input prefix yang mau dicari
				printf("Input a prefix to be searched: ");
				scanf("%[^\n]",prefix);getchar();
				
				for(int i=0;i<strlen(prefix);i++){//Mengubah semuanya jadi huruf kecil
					if(prefix[i] >= 'A' && prefix[i] <= 'Z'){
						prefix[i] = prefix[i] + 32;
					}
				}
				
				findPrefix(root, prefix);//LAkukan functionnya
				break;
			}
			case 4:
				//Untuk menprint semuanya
				PrintHeader(root);
				break;
			case 5:
				//Keluar sistem
				Exit();
				break;
			default:
				//Jika inputnya salah
				printf("Wrong input, ");
				printf(" input again.");
				break;
		}
		printf("\nPress enter to continue...");getchar();
	} while(1);
	
	return 0;
}
